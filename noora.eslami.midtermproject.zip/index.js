function rectangleName(name) {
  document.getElementById("result").innerHTML = name;
}
